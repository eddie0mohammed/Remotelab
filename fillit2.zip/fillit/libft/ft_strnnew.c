#include <stdlib.h>
#include <string.h>

char *ft_strnnew(char *str, size_t n)
{
    char *res;
    size_t i;

    res = (char *)malloc(sizeof(char) * n);
    i = 0;
    while (i < n)
    {
        res[i] = str[i];
        i++;
    }
    return (res);
}
